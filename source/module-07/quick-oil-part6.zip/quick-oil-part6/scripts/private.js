import { renderAdminServiceRequests, handleFormSubmit } from "./requestServiceHelper.js?v=oil6";
import { initMessages } from "./getMessage.js?v=oil6";
import { validateLoggedIn } from "./validateLogin.js?v=oil6";
initMessages();
validateLoggedIn();
renderAdminServiceRequests("#requests");