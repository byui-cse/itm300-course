import { renderAdminServiceRequests, handleFormSubmit } from "./requestServiceHelper.js";
import { initMessages } from "./getMessage.js";
initMessages();
renderAdminServiceRequests("#requests");