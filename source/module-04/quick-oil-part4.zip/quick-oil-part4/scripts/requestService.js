
import { renderServiceRequests } from "./requestServiceHelper.mjs";

renderServiceRequests("#requests");