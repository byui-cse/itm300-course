/*
    get list of films
    output list of films
    when a film is clicked:
        open a new page passing the ID of the film through the URL

*/
import { renderServiceRequests } from "./requestServiceHelper.mjs";

renderServiceRequests("#requests");