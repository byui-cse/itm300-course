import { initMessages } from "./getMessage.js?v=oil4";
initMessages();

