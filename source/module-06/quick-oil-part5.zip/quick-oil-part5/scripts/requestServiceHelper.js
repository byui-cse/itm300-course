const baseUrl = "REPLACE-WITH-INVOKE-URL";


function requestTemplate(serviceRequest) {
        return `<h3>Ticket #${serviceRequest.service_id}</h3><div>${serviceRequest.service_description}<br>(***) ***-${serviceRequest.phone_number.substr(serviceRequest.phone_number.length - 4)}</div>`;
  }

// pass in the element selector you would like the list rendered in
export async function renderServiceRequests(elementSelector) {
    const element = document.querySelector(elementSelector);
    let serviceRequests = await makeRequest(baseUrl + "/service-request");
    console.log(serviceRequests);

    // serviceRequests = serviceRequests.results;
    // console.log(serviceRequests);
  
    element.innerHTML = "<h1>Current Service Requests</h1>"+serviceRequests.map(requestTemplate).join("");
  }  

// Function to handle form submission
export const handleFormSubmit = async (event) => {
  event.preventDefault(); // Prevent default form submission behavior

  const form = event.target;
  const formData = new FormData(form);

  // Extract form data
  const phone = formData.get("phone");
  const service = formData.get("service");

  // Validate form data
  if (!phone || !service) {
    alert("Please fill out all fields.");
    return;
  }

  // Prepare service request data
  const requestBody = {
    service_description: service,
    phone_number: phone,
  };

  try {
    // Add service request to DynamoDB
    const response = await addDynamoServiceRequest(requestBody);

    // Display success message or perform additional actions
    // console.log("Service request added successfully:", response);
    const msgElement = document.querySelector("#message");
    msgElement.classList.add("show");
    msgElement.innerHTML = response;

    // Optionally, reset the form after successful submission
    form.reset();
  } catch (error) {
    console.error("Error adding service request:", error);
    // alert("Failed to submit service request. Please try again later.");
  }
};


async function addDynamoServiceRequest(requestBody)
{
  let response = await makeRequest(baseUrl + "/service-request", requestBody);
  return response;
}
 
async function makeRequest(url, requestBody = null) {
  try {
    const options = {
      method: requestBody ? "POST" : "GET", // Use POST if requestBody is provided, otherwise use GET
      headers: {
        "Content-Type": "application/json",
      },
      body: requestBody ? JSON.stringify(requestBody) : null, // Convert requestBody to JSON if provided
    };

    const response = await fetch(url, options);

    if (response.ok) {
      return await response.json(); // Parse response body as JSON
    } else {
      const error = await response.text();
      throw new Error(error);
    }
  } catch (err) {
    console.error("Error making request:", err);
    throw err; // Re-throw the error to handle it further up the call stack
  }
}