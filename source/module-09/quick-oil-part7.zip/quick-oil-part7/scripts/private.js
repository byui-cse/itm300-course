import {renderAdminServiceRequests, handleFormSubmit } from "./requestServiceHelper.js";
import { initMessages } from "./getMessage.js";
import { validateLoggedIn, refreshToken } from "./validateLogin.js";
initMessages();
validateLoggedIn();
renderAdminServiceRequests("#requests");

document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('vehicle-history-form');
  
    form.addEventListener('submit', (event) => {
      event.preventDefault(); // Prevent default form submission
  
      const licensePlate = document.getElementById('license_plate').value;
  
      // Perform the action you need with the form data
      // For example, open the vehicle-history.html page with the license_plate parameter
      window.open(`vehicle-history.html?license_plate=${licensePlate}`, '_blank');
  
      // Clear the form after submission
      form.reset();
    });
  });
