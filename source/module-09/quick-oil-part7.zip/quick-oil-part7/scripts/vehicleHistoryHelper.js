import appConfig from './settings.js';
import {addQuickMessage} from './getMessage.js';

// const status_options = ["New Request","Quoted - Waiting for Approval","Accepted","Approved - Bring Vehicle In", "Waiting for Parts","Being Serviced","Complete. Pick up Vehicle","Completed","Service Rejected"];

const baseUrl = appConfig.BaseURL;


function requestAdminVehicleHistoryTemplate(vehicleHistory) {
  try {
    return `<section class='admin-service-request'><h3>Ticket #${vehicleHistory.service_id ?? ""}<br>${vehicleHistory.phone_number ?? ""} </h3><strong>${vehicleHistory.service_status ?? ""}</strong> ${vehicleHistory.completion_date ?? ""}<br>${vehicleHistory.service_description ?? ""}</div></section>`;
  } catch (error) {
    return "Error retrieving data. Please check field values.";
  }
}



// pass in the element selector you would like the list rendered in
export async function renderAdminVehicleHistory(elementSelector, license_plate) {
  const element = document.querySelector(elementSelector);
  let vehicleHistories = await makeRequest(baseUrl + "/admin-service-request/vehicle-history/"+license_plate,"GET");
  console.log(vehicleHistories);

  element.innerHTML = "<h1>Vehicle History for "+license_plate+"</h1>"+vehicleHistories.map(requestAdminVehicleHistoryTemplate).join("");
}   


async function makeRequest(url, requestBody = null, actionType="GET") {
  try {
    console.log(actionType);
    let options = {
      method: actionType, 
      headers: {
        "Content-Type": "application/json",
      },
      body: actionType != "GET" ? JSON.stringify(requestBody) : null, // Convert requestBody to JSON if provided
    };
    const jwtToken = getIdToken();
    if (jwtToken) {
      options.headers["Authorization"] = `Bearer ${jwtToken}`;
    }   

    const response = await fetch(url, options);

    if (response.ok) {
      return await response.json(); // Parse response body as JSON
    } else {
      const error = await response.text();
      throw new Error(error);
    }
  } catch (err) {
    console.error("Error making request:", err);
    throw err; // Re-throw the error to handle it further up the call stack
  }
}

function getIdToken() {
  const loginName = localStorage.getItem('CognitoIdentityServiceProvider.'+appConfig.ClientId+'.LastAuthUser'); 
  const idToken = localStorage.getItem('CognitoIdentityServiceProvider.'+appConfig.ClientId+'.'+loginName+".idToken");
  return idToken;
}



