import appConfig from './settings.js';
export async function validateLoggedIn() {
document.addEventListener('DOMContentLoaded', async () => {
    const jwtToken = localStorage.getItem('jwtToken');
    if (jwtToken) {
        try {
            const verificationResult = await verifyToken(jwtToken);
            if(verificationResult==true){
            console.log('Token is valid:', verificationResult);
            }
            else {
                console.error('Token verification failed:', error);
                // Handle token verification failure (e.g., redirect to login page)
                window.location.href = 'login.html?msg=2';               
            }
            // Add your logic here after successful token verification
        } catch (error) {
            console.error('Token verification failed:', error);
            // Handle token verification failure (e.g., redirect to login page)
            window.location.href = 'login.html?msg=2';
        }
    } else {
        // No token found, redirect to login page
        window.location.href = 'login.html';
        console.log('NOPPPPPE');
    }
});
}
export async function verifyToken(jwtToken) {
    var base64Url = jwtToken.split('.')[1];
    var base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
    var jsonPayload = decodeURIComponent(window.atob(base64).split('').map(function(c) {
        return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
    }).join(''));
    
    let jsondata = JSON.parse(jsonPayload);
    // refreshToken()
    // .then(accessToken => {
    //     //console.log('JWT Token:', accessToken);
    //     // localStorage.setItem('jwtToken', accessToken);
    //     // Redirect to private page
    //     window.location.href = 'index.html?msg=refreshing';
    // })

    // .catch(err => {
    //     console.error('Authentication error:', err);
    //     window.location.href= 'login.html?msg=0';
    // });  
    // console.log(jsondata.exp);
    // console.log(Date.now()/1000)
    // console.log(jsondata.exp,Date.now()/1000);
    return (jsondata.exp - Date.now()/1000)>0;
    //return true;
}

// function refreshToken() {
//     console.log("tyring to refresh");
//     const refreshToken = getRefreshToken();
//     const username = getUsername();

//     if (!refreshToken || !username) {
//         return Promise.reject('No refresh token available.');
//     }

//     const poolData = {
//         UserPoolId: appConfig.UserPoolId,
//         ClientId: appConfig.ClientId
//     };

//     const userPool = new AmazonCognitoIdentity.CognitoUserPool(poolData);

//     const userData = {
//         Username: username,
//         Pool: userPool
//     };

//     const cognitoUser = new AmazonCognitoIdentity.CognitoUser(userData);

//     return new Promise((resolve, reject) => {
//         cognitoUser.refreshSession(new AmazonCognitoIdentity.CognitoRefreshToken({ RefreshToken: refreshToken }), (err, session) => {
//             if (err) {
//                 console.log(err);
//                 reject(err);
//             } else {
//                 const newAccessToken = session.getAccessToken().getJwtToken();
//                 localStorage.setItem('jwtToken', newAccessToken);
//                 resolve(newAccessToken);
//             }
//         });
//     });
// }
// function getRefreshToken() {
//     const loginName = localStorage.getItem('CognitoIdentityServiceProvider.'+appConfig.ClientId+'.LastAuthUser'); 
//     const idToken = localStorage.getItem('CognitoIdentityServiceProvider.'+appConfig.ClientId+'.'+loginName+".refreshToken");
//     return idToken;
//   }
//   function getUsername() {
//     const loginName = localStorage.getItem('CognitoIdentityServiceProvider.'+appConfig.ClientId+'.LastAuthUser'); 
//     return loginName;
//   }  