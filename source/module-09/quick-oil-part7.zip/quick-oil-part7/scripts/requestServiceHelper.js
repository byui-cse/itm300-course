import appConfig from './settings.js';
import { addQuickMessage } from './getMessage.js';
import { verifyToken } from './validateLogin.js';
import { makeRequest } from './utilities.js';

const statusOptions = [
  'New Request', 'Quoted - Waiting for Approval', 'Accepted', 
  'Approved - Bring Vehicle In', 'Waiting for Parts', 
  'Being Serviced', 'Complete. Pick up Vehicle', 
  'Completed', 'Service Rejected'
];

const baseUrl = appConfig.BaseURL;

/**
 * Generates HTML template for a service request.
 * @param {Object} serviceRequest - The service request object.
 * @returns {string} - HTML string representing the service request.
 */
function requestTemplate(serviceRequest) {
  try {
    if (!serviceRequest || !serviceRequest.service_id || !serviceRequest.phone_number || !serviceRequest.service_status) {
      throw new Error('Missing data');
    }

    const statusLevel = statusOptions.indexOf(serviceRequest.service_status) + 1;
    if (statusLevel === 0) {
      throw new Error('Invalid service status');
    }

    const percentage = (statusLevel / (statusOptions.length - 2)) * 100;

    return `<h3>Ticket #${serviceRequest.service_id}<br>(***) ***-${serviceRequest.phone_number}</h3>
      <div class='serviceinfo'>
        <div class="w3-light-gray">
          <div class="w3-gray" style="height:24px;width:${percentage}%"></div>
        </div>
        <strong>${serviceRequest.service_status}</strong>
      </div>`;
  } catch (error) {
    console.error(error);
    return 'Error retrieving data. Please check field values.';
  }
}

/**
 * Generates HTML template for an admin service request.
 * @param {Object} serviceRequest - The service request object.
 * @returns {string} - HTML string representing the admin service request.
 */
function requestAdminTemplate(serviceRequest) {
  return `<section class='admin-service-request'>
    <h3>Ticket #${serviceRequest.service_id}</h3>
    <div>
      ${serviceRequest.service_description}<br>
      ${serviceRequest.phone_number}<br>
      <a target="_blank" href="vehicle-history.html?license_plate=${serviceRequest.license_plate}">
        <span class='plate'>${serviceRequest.license_plate}
          <span class="tooltiptext">Vehicle History</span>
        </span>
      </a>
    </div>
    <div>
      Status: 
      <form class='updateStatus'>
        <input type='hidden' name='license_plate' value='${serviceRequest.license_plate}'>
        <input type='hidden' name='service_id' value='${serviceRequest.service_id}'>
        <select name='service_status'>${buildServiceDropDown(serviceRequest.service_status)}</select>
        <button class='btn' type='submit'>Update Status</button>
      </form>
    </div>
  </section>`;
}

/**
 * Renders service requests to the specified HTML element.
 * @param {string} elementSelector - The selector for the HTML element.
 */
export async function renderServiceRequests(elementSelector) {
  try {
    const element = document.querySelector(elementSelector);
    const serviceRequests = await makeRequest(`${baseUrl}/service-request`, 'GET');
    // console.log(serviceRequests);

    element.innerHTML = '<h1>Current Service Requests</h1>' + serviceRequests.map(requestTemplate).join('');
  } catch (error) {
    // console.error('Error rendering service requests:', error);
  }
}

/**
 * Renders admin service requests to the specified HTML element.
 * @param {string} elementSelector - The selector for the HTML element.
 */
export async function renderAdminServiceRequests(elementSelector) {
  try {
    const element = document.querySelector(elementSelector);
    const serviceRequests = await makeRequest(`${baseUrl}/admin-service-request`, 'GET');
    // console.log(serviceRequests);

    element.innerHTML = '<h1>Current Service Requests</h1>' + serviceRequests.map(requestAdminTemplate).join('');
    updateFormTriggers();
  } catch (error) {
    // console.error('Error rendering admin service requests:', error);
  }
}

/**
 * Handles the form submission for adding a service request.
 * @param {Event} event - The form submit event.
 */
export const handleFormSubmit = async (event) => {
  event.preventDefault();

  const form = event.target;
  const formData = new FormData(form);

  const phone = formData.get('phone');
  const service = formData.get('service');
  const licensePlate = formData.get('license_plate');

  if (!phone || !service || !licensePlate) {
    addQuickMessage('Please fill out all fields.');
    return;
  }

  const requestBody = {
    service_description: service,
    phone_number: phone,
    license_plate: licensePlate,
  };

  try {
    const response = await addDynamoServiceRequest(requestBody);
    addQuickMessage(response);
    form.reset();
  } catch (error) {
    console.error('Error adding service request:', error);
  }
};

/**
 * Adds a service request to DynamoDB.
 * @param {Object} requestBody - The service request data.
 * @returns {Promise<Object>} - The response from the server.
 */
async function addDynamoServiceRequest(requestBody) {
  try {
    const response = await makeRequest(`${baseUrl}/service-request`, requestBody, 'POST');
    return response;
  } catch (error) {
    console.error('Error in addDynamoServiceRequest:', error);
    throw error;
  }
}

/**
 * Builds the service status dropdown options.
 * @param {string} current - The current service status.
 * @returns {string} - HTML string for the dropdown options.
 */
function buildServiceDropDown(current) {
  return statusOptions.map(element => {
    const selected = current === element ? "selected='selected'" : '';
    return `<option ${selected} name='${element}'>${element}</option>`;
  }).join('');
}

/**
 * Adds event listeners to forms for updating service status.
 */
function updateFormTriggers() {
  const forms = document.querySelectorAll('.updateStatus');
  forms.forEach(form => {
    form.addEventListener('submit', async function (event) {
      event.preventDefault();

      try {
        const verificationResult = await verifyToken();
        if (verificationResult) {
          const licensePlate = form.querySelector('input[name="license_plate"]').value;
          const serviceId = form.querySelector('input[name="service_id"]').value;
          const serviceStatus = form.querySelector('select[name="service_status"]').value;

          const requestBody = {
            license_plate: licensePlate,
            service_status: serviceStatus
          };

          const response = await makeRequest(`${baseUrl}/admin-service-request/${serviceId}`, requestBody, 'PUT');
          addQuickMessage(response);
          renderAdminServiceRequests('#requests');
        } else {
          window.location.href = 'login.html?msg=2';
        }
      } catch (error) {
        console.error('Error updating service status:', error);
      }
    });
  });
}
