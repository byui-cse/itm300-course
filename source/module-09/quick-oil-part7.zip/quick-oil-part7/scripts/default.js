import { updateNavForAdmins } from "./utilities.js";

updateNavForAdmins();