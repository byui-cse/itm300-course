import { renderAdminVehicleHistory } from "./vehicleHistoryHelper.js";
import { initMessages } from "./getMessage.js";
import { validateLoggedIn } from "./validateLogin.js";
import { getQueryParam } from "./utilities.js";
initMessages();
validateLoggedIn();

// Get the license_plate query parameter
const licensePlate = getQueryParam("license_plate");

// Call the renderAdminVehicleHistory function with the license_plate parameter
renderAdminVehicleHistory("#requests", licensePlate);