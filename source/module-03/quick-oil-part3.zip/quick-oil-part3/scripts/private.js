import { initMessages } from "./getMessage.js?v=oil3";
initMessages();

