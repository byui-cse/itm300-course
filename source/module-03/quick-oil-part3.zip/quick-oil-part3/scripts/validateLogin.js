
document.addEventListener('DOMContentLoaded', async () => {
    const jwtToken = localStorage.getItem('jwtToken');
    if (jwtToken) {
        try {
            const verificationResult = await verifyToken(jwtToken);
            if(verificationResult==true){
            console.log('Token is valid:', verificationResult);
            }
            else {
                console.error('Token verification failed:', error);
                // Handle token verification failure (e.g., redirect to login page)
                window.location.href = 'login.html?msg=2';               
            }
            // Add your logic here after successful token verification
        } catch (error) {
            console.error('Token verification failed:', error);
            // Handle token verification failure (e.g., redirect to login page)
            window.location.href = 'login.html?msg=2';
        }
    } else {
        // No token found, redirect to login page
        window.location.href = 'login.html';
        console.log('NOPPPPPE');
    }
});

function verifyToken(jwtToken) {
    var base64Url = jwtToken.split('.')[1];
    var base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
    var jsonPayload = decodeURIComponent(window.atob(base64).split('').map(function(c) {
        return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
    }).join(''));
    
    jsondata = JSON.parse(jsonPayload);
    // console.log(jsondata.exp);
    // console.log(Date.now()/1000)
    return (jsondata.exp - Date.now()/1000)>0;
    //return true;
}