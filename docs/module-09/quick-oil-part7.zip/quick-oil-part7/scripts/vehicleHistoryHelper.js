import appConfig from './settings.js?v=oil7';
import { addQuickMessage } from './getMessage.js?v=oil7';
import { makeRequest } from './utilities.js?v=oil7';

const baseUrl = appConfig.BaseURL;


function requestAdminVehicleHistoryTemplate(vehicleHistory) {
  try {
    return `<section class='admin-service-request'><h3>Ticket #${vehicleHistory.service_id ?? ""}<br>${vehicleHistory.phone_number ?? ""} </h3><strong>${vehicleHistory.service_status ?? ""}</strong> ${vehicleHistory.completion_date ?? ""}<br>${vehicleHistory.service_description ?? ""}</div></section>`;
  } catch (error) {
    return "Error retrieving data. Please check field values.";
  }
}



// pass in the element selector you would like the list rendered in
export async function renderAdminVehicleHistory(elementSelector, license_plate) {
  const element = document.querySelector(elementSelector);
  let vehicleHistories = await makeRequest(baseUrl + "/admin-service-request/vehicle-history/" + license_plate, "GET");
  // console.log(vehicleHistories);
  document.querySelector("#plate").innerHTML = license_plate;
  element.innerHTML = vehicleHistories.map(requestAdminVehicleHistoryTemplate).join("");
}   