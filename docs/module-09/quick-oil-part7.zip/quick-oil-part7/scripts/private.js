import { renderAdminServiceRequests, handleFormSubmit } from "./requestServiceHelper.js";
import { initMessages } from "./getMessage.js";
import { validateLoggedIn } from "./validateLogin.js";
initMessages();
validateLoggedIn();
renderAdminServiceRequests("#requests");