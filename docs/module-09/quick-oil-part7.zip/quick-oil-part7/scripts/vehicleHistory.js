import { renderAdminVehicleHistory } from "./vehicleHistoryHelper.js?v=oil7";
import { initMessages } from "./getMessage.js?v=oil7";
import { validateLoggedIn } from "./validateLogin.js?v=oil7";
import { getQueryParam } from "./utilities.js?v=oil7";
initMessages();
validateLoggedIn();

// Get the license_plate query parameter
const licensePlate = getQueryParam("license_plate");

// Call the renderAdminVehicleHistory function with the license_plate parameter
renderAdminVehicleHistory("#requests", licensePlate);