import { renderAdminVehicleHistory } from "./vehicleHistoryHelper.js";
import { initMessages } from "./getMessage.js";
import { validateLoggedIn } from "./validateLogin.js";
initMessages();
validateLoggedIn();

// Function to get query parameters from the URL
const getQueryParam = (param) => {
    const urlParams = new URLSearchParams(window.location.search);
    return urlParams.get(param);
};

// Get the license_plate query parameter
const licensePlate = getQueryParam("license_plate");

// Call the renderAdminVehicleHistory function with the license_plate parameter
renderAdminVehicleHistory("#requests", licensePlate);