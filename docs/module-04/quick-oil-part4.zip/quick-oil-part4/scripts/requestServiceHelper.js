const baseUrl = "REPLACE-WITH-INVOKE-URL";


function requestTemplate(serviceRequest) {
        return `<h3>Ticket #${serviceRequest.service_id}</h3><div>${serviceRequest.service_description}<br>(***) ***-${serviceRequest.phone.substr(serviceRequest.phone_number.length - 4)}</div>`;
  }

// pass in the element selector you would like the list rendered in
export async function renderServiceRequests(elementSelector) {
    const element = document.querySelector(elementSelector);
    let serviceRequests = await makeRequest(baseUrl + "/service-request");
    console.log(serviceRequests);

    // serviceRequests = serviceRequests.results;
    // console.log(serviceRequests);
  
    element.innerHTML = "<h1>Current Service Requests</h1>"+serviceRequests.map(requestTemplate).join("");
  }  

  /*************HELPER FUNCTIONS************/

async function makeRequest(url) {
    // we wrap our attempt to get our data from the API in a try/catch block. This gives us better control over what happens if something goes wrong. We can handle errors gracefully instead of things crashing
    try {
      const response = await fetch(url);
      if (response.ok) {
        return await response.json();
      } else {
        const error = await response.text();
        throw new Error(error);
      }
    } catch (err) {
      // normally we would do more than just log out the error...it's always good to notify the user that something went wrong and if it's something they need to worry about or if it is outside of their control.
      console.log(err);
    }
  }