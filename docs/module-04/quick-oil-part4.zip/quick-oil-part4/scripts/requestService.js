
import { renderServiceRequests } from "./requestServiceHelper.js";

renderServiceRequests("#requests");