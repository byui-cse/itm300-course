
import { renderServiceRequests, handleFormSubmit } from "./requestServiceHelper.js?v=oil6";

// Event listener for form submission
document.addEventListener("DOMContentLoaded", () => {
    const form = document.querySelector(".formgrid");
    if (form) {
      form.addEventListener("submit", handleFormSubmit);
    }
  }); 
  
renderServiceRequests("#requests");