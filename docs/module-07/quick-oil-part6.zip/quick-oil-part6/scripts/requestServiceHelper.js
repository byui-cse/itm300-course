import appConfig from './settings.js';
import {addQuickMessage} from './getMessage.js';

const status_options = ["New Request","Quoted - Waiting for Approval","Accepted","Approved - Bring Vehicle In", "Waiting for Parts","Being Serviced","Complete. Pick up Vehicle","Completed","Service Rejected"];

const baseUrl = appConfig.BaseURL;


function requestTemplate(serviceRequest) {
    const status_level = status_options.indexOf(serviceRequest.service_status)+1;
    const percentage = (status_level /(status_options.length-2))*100;
        return `<h3>Ticket #${serviceRequest.service_id}<br>(***) ***-${serviceRequest.phone_number} </h3><div class='serviceinfo'><div class="w3-light-gray">
  <div class="w3-gray" style="height:24px;width:${percentage}%"></div>
</div><strong>${serviceRequest.service_status}</strong></div>`;
  }
  function requestAdminTemplate(serviceRequest) {

    return `<section class='admin-service-request'><h3>Ticket #${serviceRequest.service_id}</h3><div>${serviceRequest.service_description}<br>${serviceRequest.phone_number}</div><div>Status: <form class='updateStatus'><input type='hidden' name='license_plate' value='${serviceRequest.license_plate}'><input type='hidden' name='service_id' value='${serviceRequest.service_id}'><select name='service_status'><${buildServiceDropDown(serviceRequest.service_status)}</select><button class='btn' type='submit'>Update Status</button></form></div></section>`;
}  

// pass in the element selector you would like the list rendered in
export async function renderServiceRequests(elementSelector) {
    const element = document.querySelector(elementSelector);
    let serviceRequests = await makeRequest(baseUrl + "/service-request", "GET");
    console.log(serviceRequests);

    // serviceRequests = serviceRequests.results;
    // console.log(serviceRequests);
  
    element.innerHTML = "<h1>Current Service Requests</h1>"+serviceRequests.map(requestTemplate).join("");
  }  

// pass in the element selector you would like the list rendered in
export async function renderAdminServiceRequests(elementSelector) {
  const element = document.querySelector(elementSelector);
  let serviceRequests = await makeRequest(baseUrl + "/admin-service-request","GET");
  console.log(serviceRequests);

  // serviceRequests = serviceRequests.results;
  // console.log(serviceRequests);

  element.innerHTML = "<h1>Current Service Requests</h1>"+serviceRequests.map(requestAdminTemplate).join("");
  updateFormTriggers();
}   

// Function to handle form submission
export const handleFormSubmit = async (event) => {
  event.preventDefault(); // Prevent default form submission behavior

  const form = event.target;
  const formData = new FormData(form);

  // Extract form data
  const phone = formData.get("phone");
  const service = formData.get("service");
  const license_plate = formData.get("license_plate");

  // Validate form data
  if (!phone || !service || !license_plate) {
    addQuickMessage("Please fill out all fields.");
    return;
  }

  // Prepare service request data
  const requestBody = {
    service_description: service,
    phone_number: phone,
    license_plate: license_plate,
  };

  try {
    // Add service request to DynamoDB
    const response = await addDynamoServiceRequest(requestBody);

    // Display success message or perform additional actions
    addQuickMessage(response);

    // Optionally, reset the form after successful submission
    form.reset();
  } catch (error) {
    console.error("Error adding service request:", error);
    // alert("Failed to submit service request. Please try again later.");
  }
};


async function addDynamoServiceRequest(requestBody)
{
  let response = await makeRequest(baseUrl + "/service-request", requestBody,"POST");
  return response;
}
 
async function makeRequest(url, requestBody = null, actionType="GET") {
  try {
    console.log(actionType);
    let options = {
      method: actionType, 
      headers: {
        "Content-Type": "application/json",
      },
      body: actionType != "GET" ? JSON.stringify(requestBody) : null, // Convert requestBody to JSON if provided
    };
    const jwtToken = getIdToken();
    if (jwtToken) {
      options.headers["Authorization"] = `Bearer ${jwtToken}`;
    }   

    const response = await fetch(url, options);

    if (response.ok) {
      return await response.json(); // Parse response body as JSON
    } else {
      const error = await response.text();
      throw new Error(error);
    }
  } catch (err) {
    console.error("Error making request:", err);
    throw err; // Re-throw the error to handle it further up the call stack
  }
}

function getIdToken() {
  const loginName = localStorage.getItem('CognitoIdentityServiceProvider.'+appConfig.ClientId+'.LastAuthUser'); 
  const idToken = localStorage.getItem('CognitoIdentityServiceProvider.'+appConfig.ClientId+'.'+loginName+".idToken");
  return idToken;
}

function buildServiceDropDown(current) {

  let output = "";
  status_options.forEach(element => {
    let selected = current == element ? "selected='selected'" : "";
    output += `<option ${selected} name='${element}'>${element}</option>`;
  });
  return output;
}

function updateFormTriggers() {
    const forms = document.querySelectorAll('.updateStatus');
    forms.forEach(form => {
        form.addEventListener('submit', async function (event) {
            event.preventDefault();
            
            const licensePlate = form.querySelector('input[name="license_plate"]').value;
            const serviceId = form.querySelector('input[name="service_id"]').value;
            const serviceStatus = form.querySelector('select[name="service_status"]').value;
            
            const requestBody = {
                license_plate: licensePlate,
                service_status: serviceStatus
            };
            // console.log(requestBody);
            let response = await makeRequest(baseUrl + "/admin-service-request/" + serviceId, requestBody, "PUT");
            addQuickMessage(response);

        });
    });
}


