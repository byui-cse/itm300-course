import { updateNavForAdmins } from "./utilities.js?v=oil6";

updateNavForAdmins();