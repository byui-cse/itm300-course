const appConfig = {
UserPoolId: 'REPLACE-WITH-YOUR-USER-POOL-ID',
ClientId: 'REPLACE-WITH-YOUR-CLIENT-ID',
BaseURL: 'REPLACE-WITH-INVOKE-URL',
HostedId: 'REPLACE-WITH-COGNITO-URL/oauth2/authorize?client_id=REPLACE-WITH-CLIENT-ID&response_type=token&scope=email+openid+phone&redirect_uri=REPLACE-WITH-EC2-URL%2F'
}

export default appConfig;
