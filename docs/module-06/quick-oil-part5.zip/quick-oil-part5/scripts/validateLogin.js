import appConfig from './settings.js?v=oil5';
export async function validateLoggedIn() {
document.addEventListener('DOMContentLoaded', async () => {

        try {
            const verificationResult = await verifyToken();
            if(verificationResult){
            // console.log('Token is valid:', verificationResult);
            // refreshToken();
            // console.log("refreshed");

            }
            else {
                console.error('Token verification failed. Attempting to refresh:', error);
                refreshToken();
                    const verificationResult = await verifyToken();
                    if(verificationResult){
                    console.log('Token is valid:', verificationResult);
                    // refreshToken();
                    // console.log("refreshed");
                    }else {
                        // Handle token verification failure (e.g., redirect to login page) 
                        window.location.href = 'login.html?msg=2&refresh=false';               
                    }              
                // console.log("refreshed");
            }
            // Add your logic here after successful token verification
        } catch (error) {
            console.error('Token verification failed:', error);
            // Handle token verification failure (e.g., redirect to login page)
            console.log('here');
            window.location.href = 'login.html?msg=2';
        }
});
}
export async function verifyToken(){
    const poolData = {
      UserPoolId: appConfig.UserPoolId,
      ClientId: appConfig.ClientId        
    };
    const userPool = new AmazonCognitoIdentity.CognitoUserPool(poolData);
  
  
    const loginName = userPool.getCurrentUser();
    // console.log(loginName.refreshToken);
    if(loginName){
        const valid = await loginName.getSession(function(err, data) {
        if (err) {
            // Prompt the user to reauthenticate by hand...
        } else {
            return data.isValid();
        }
        });
        return valid;
    }
    return false;
}

export function refreshToken() {
    console.log("refreshing");
    const poolData = {
        UserPoolId: appConfig.UserPoolId,
        ClientId: appConfig.ClientId        
    };
    const userPool = new AmazonCognitoIdentity.CognitoUserPool(poolData);

    const cognitoUser = userPool.getCurrentUser();

    if (!cognitoUser) {
        console.error("No user currently logged in.");
        return;
    }

    cognitoUser.getSession(function(err, session) {
        if (err) {
            console.error(err);
            // Prompt the user to reauthenticate by hand...
            return;
        }

        const refreshToken = session.getRefreshToken();
        console.log(refreshToken);

        const authDetails = {
            ClientId: appConfig.ClientId,
            AuthFlow: 'REFRESH_TOKEN_AUTH',
            AuthParameters: {
                'REFRESH_TOKEN': refreshToken.getToken()
            }
        };

        const cognitoIdentityServiceProvider = new AWS.CognitoIdentityServiceProvider({
            region: 'us-east-1' // Set your AWS region here
        });
        cognitoIdentityServiceProvider.initiateAuth(authDetails, function(err, authResult) {
            if (err) {
                console.error(err);
                return;
            }

            const newAccessToken = authResult.AuthenticationResult.AccessToken;
            const newIdToken = authResult.AuthenticationResult.IdToken;

            // Build the key names using the pool ID, client ID, and username
            const keyPrefix = `CognitoIdentityServiceProvider.${appConfig.ClientId}.${cognitoUser.username}`;
            const idTokenKey = `${keyPrefix}.idToken`;
            const accessTokenKey = `${keyPrefix}.accessToken`;

            // Update localStorage with the new tokens
            localStorage.setItem(idTokenKey, newIdToken);
            localStorage.setItem(accessTokenKey, newAccessToken);

            console.log("Tokens updated successfully:", newAccessToken, newIdToken);
        });
    });
}
