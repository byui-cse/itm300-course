import { initMessages } from "./getMessage.js?v=oil5";
initMessages();

